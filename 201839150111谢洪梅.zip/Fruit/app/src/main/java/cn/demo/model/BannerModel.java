package cn.demo.model;

import java.util.List;


public class BannerModel {
    public List<String> imgs;
    public List<String> tips;
}