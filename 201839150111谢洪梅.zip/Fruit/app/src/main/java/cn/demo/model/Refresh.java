package cn.demo.model;

public interface Refresh{
    public void doRefresh();
}
