package cn.demo.ui.fragment;


import android.content.Intent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import cn.demo.FruitContext;
import cn.demo.R;
import cn.demo.base.BaseFragment;


import butterknife.OnClick;
import cn.demo.http.model.User;
import cn.demo.ui.activity.LoginActivity;
import cn.demo.ui.activity.MainActivity;

/**
 * Created by Administrator on 2018/3/24.
 */

public class MineFragment extends BaseFragment
{

    private Intent intent;

    @Override
    protected int getResourceId() {
        return R.layout.fragment_mine;
    }

    private TextView phone;
    private LinearLayout user_orders;
    User user;
    @Override
    public void initView(View rootView) {
        super.initView(rootView);
        phone = rootView.findViewById(R.id.phone);
        user_orders = rootView.findViewById(R.id.user_orders);
        user_orders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity mainActivity = (MainActivity) getActivity();
                mainActivity.clickTab(2);
            }
        });

        user = FruitContext.getInstance().getCurrentUser();
        if(user!=null){
            phone.setText("账号："+user.getUser_name());
        }else {
            phone.setText("登录/注册");
        }

        phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(user ==null){
                    Intent intent = new Intent(getActivity(),LoginActivity.class);
                    startActivity(intent);
                }
            }
        });
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        user = FruitContext.getInstance().getCurrentUser();
        if(user!=null){
            phone.setText("账号："+user.getUser_name());
        }else {
            phone.setText("登录/注册");
        }
    }

    @OnClick({R.id.user_login,R.id.user_signIn,R.id.user_redeem,R.id.user_orders,R.id.user_afterSale,
              R.id.user_address,R.id.user_account,R.id.user_dreamTree,R.id.user_footprint,R.id.user_suggestion})
    public void onViewClicked(View view){
        switch(view.getId()){
            case R.id.user_login:
                intent = new Intent(getActivity(),LoginActivity.class);
                startActivity(intent);
                break;
            case R.id.user_signIn:
                break;
            case R.id.user_redeem:
                break;
            case R.id.user_orders:
                break;
            case R.id.user_afterSale:
                break;
            case R.id.user_address:
                break;
            case R.id.user_account:
                break;
            case R.id.user_dreamTree:
                break;
            case R.id.user_footprint:
                break;
            case R.id.user_suggestion:
                break;
            default:
                break;
        }
    }



}