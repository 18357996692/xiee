package cn.demo.ui.activity;

import android.app.Activity;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import cn.demo.R;
import cn.demo.base.BaseActivity;
import cn.demo.http.adapter.GoodsAdapter;
import cn.demo.http.model.Goods;



public class GoodListActivity extends BaseActivity {

    public static Bitmap b;

    @Override
    protected int getResourceId() {
        return R.layout.activity_goodlist;
    }

    List<Goods> dataList = new ArrayList<>();
    int type = 0;
    public void initView()
    {
        super.initView();
        b = getBitmapFromResources(this, R.drawable.ic_launcher);

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        type = getIntent().getIntExtra("type",0);
        if(type == 1||type == 0){
            Goods data = new Goods("新疆哈密瓜", "正宗新疆哈密瓜西州蜜精品果 西周蜜瓜25号甜瓜香瓜","https://img14.360buyimg.com/n5/jfs/t1/41936/27/5750/320853/5cf47a4cE208e4eec/07e40eb1fbee8a3d.jpg");
            dataList.add(data);
            data = new Goods("小香瓜", "绿宝石甜瓜小香瓜新鲜水果东北蜜瓜5斤当季整箱","https://img10.360buyimg.com/n5/jfs/t1/125080/37/3448/446818/5ed225c1E18c16fd9/89fc0e9dbd0053d8.jpg");
            dataList.add(data);
            data = new Goods("白兰瓜", "新鲜水果甜瓜当季香瓜蜜瓜新疆瓜果 2-3个瓜","https://img10.360buyimg.com/n1/jfs/t1/119644/36/11977/589671/5f1fc0bdE890f5b47/c58805e539a34243.png");
            dataList.add(data);
            data = new Goods("黑美人西瓜", "缤咕 越南黑美人西瓜 1个装6-7斤","https://img11.360buyimg.com/n1/jfs/t1/31320/3/749/226639/5c403bdeE00ab0f45/49fbc517e793eb0d.jpg");
            dataList.add(data);
            data = new Goods("黄心西瓜", "味小仙 特小凤西瓜 黄瓤瓜脆甜小黄心西瓜新鲜 2个装","https://img13.360buyimg.com/n1/jfs/t19459/330/1293266445/120236/2397e8fd/5ac48b3dN361d0450.jpg");
            dataList.add(data);
        }

        if(type == 2||type == 0){
            Goods data = new Goods("红富士苹果", "一级铂金大果 单果230g以上 生鲜 新鲜水果 孕妇可食","https://img11.360buyimg.com/n1/jfs/t1/89913/18/14611/501012/5e66f576Ef721d521/c1f798e11d02e641.jpg");
            dataList.add(data);
            data = new Goods("壹农壹果", "蜜脆红富士苹果 带箱5斤(净果4.5斤) 单果约80mm冰糖心苹果 送礼","https://img10.360buyimg.com/n1/jfs/t1/97159/32/19484/382898/5e9fa1f6E51930453/b9d124298e5daf97.jpg");
            dataList.add(data);
            data = new Goods("栖霞红富士", "山东烟台栖霞红富士苹果水果新鲜当季 带箱10斤 一级大果 80-85mm","https://img13.360buyimg.com/n1/jfs/t1/88023/31/14879/159604/5e6b389aEa8de2046/c44b6fb55d04a1ad.jpg");
            dataList.add(data);
            data = new Goods("花牛苹果", "甘肃天水花牛苹果 5斤12-16个装","https://img12.360buyimg.com/n1/jfs/t1/112075/30/16611/329933/5f4db49aE2148a6a5/52f4dbf49c8bd9af.jpg");
            dataList.add(data);
            data = new Goods("新西兰皇家姬娜苹果", "3kg装 一级加力果 单果重160-190g 生鲜水果","https://img10.360buyimg.com/n1/jfs/t1/15803/2/10368/568221/5c8610a9E1e2b6464/e5273f1ddf6ada1c.jpg");
            dataList.add(data);
        }
        if(type == 3||type == 0){
            Goods data = new Goods("阳光玫瑰葡萄", "阳光玫瑰葡萄/提子 香印青提原箱2kg装 2-3串/箱 新鲜水果","https://img13.360buyimg.com/n1/jfs/t1/120917/1/8936/92005/5f2bcfa4E45dee579/272321ad722d45ab.jpg");
            dataList.add(data);
            data = new Goods("夏黑无籽葡萄", "夏黑无籽葡萄/提子 1kg装 新鲜水果","https://img10.360buyimg.com/n1/jfs/t21583/300/67535224/164227/f1843c40/5af90670Ne92313f1.jpg");
            dataList.add(data);
            data = new Goods("新疆吐鲁番无核白葡萄", "新疆吐鲁番无核白葡萄 新鲜水果 水晶青提 无籽马奶提子 带箱5.5-6斤【出口品质】","https://img13.360buyimg.com/n1/jfs/t1/149625/6/7914/168054/5f574284E53de403d/7e656930ac3e419d.jpg");
            dataList.add(data);
            data = new Goods("国产红提", "国产红提 葡萄/提子 1kg装 新鲜水果","https://img12.360buyimg.com/n1/jfs/t22426/282/840809538/343807/380eec9b/5b19119eNe959e6b9.jpg");
            dataList.add(data);
            data = new Goods("金手指无籽黑提", "金手指无籽黑提3斤 蓝宝石葡萄美人指提子新鲜水果 澳洲进口品种","https://img12.360buyimg.com/n1/jfs/t1/140937/38/7402/93501/5f4f6a7cEc6088d44/a9311f2a26fe593f.jpg");
            dataList.add(data);
        }


        if(type == 4||type == 0){
            Goods data = new Goods("凯特芒果", "四川攀枝花凯特芒果 2.5kg装 单果400g以上 新鲜水果","https://img10.360buyimg.com/n1/jfs/t24085/239/1438169906/480700/6ebfe578/5b618461N8b536ada.jpg");
            dataList.add(data);
            data = new Goods("优仙果", "优仙果 越南玉芒青芒果5斤装 单果200g起 大青芒果 新鲜水果","https://img10.360buyimg.com/n1/jfs/t1/98787/32/13074/103392/5e532d13Ebd7c8802/a6e640c9af28b671.jpg");
            dataList.add(data);
            data = new Goods("至诚芒果", "至诚芒果生鲜水果芒果 2斤实惠装京东生鲜 新鲜水果","https://img14.360buyimg.com/n1/jfs/t25312/134/1983666171/147642/a17b1b62/5bc19e2eNf9565de8.jpg");
            dataList.add(data);
            data = new Goods("金煌芒", "芒果金煌芒水仙芒黄皮青皮大芒果金煌芒10斤5斤送礼佳品 净重5斤 中果(单果一斤以下)","https://img10.360buyimg.com/n1/jfs/t1/134634/31/6680/907235/5f31243cEca9f9200/37ddf56103175157.png");
            dataList.add(data);
            data = new Goods("优选大芒果", "玖原农珍 越南进口青芒5斤优选大芒果 单果200-350g","https://img11.360buyimg.com/n1/jfs/t1/91070/5/17819/162780/5e8bfb88E1dc57cba/8cacbd0452e5a8d9.png");
            dataList.add(data);
        }

        GoodsAdapter adapter = new GoodsAdapter(this,dataList);
        recyclerView.setAdapter(adapter);
    }


    public static Bitmap getBitmapFromResources(Activity act, int resId) {
        Resources res = act.getResources();
        return BitmapFactory.decodeResource(res, resId);
    }
}

