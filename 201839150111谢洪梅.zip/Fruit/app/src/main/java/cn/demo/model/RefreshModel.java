package cn.demo.model;


public class RefreshModel {
    public String title;
    public String detail;

    public RefreshModel() {
    }

    public RefreshModel(String title, String detail) {
        this.title = title;
        this.detail = detail;
    }
}