package cn.demo.ui.activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import butterknife.Bind;
import cn.demo.R;
import cn.demo.base.BaseActivity;
import cn.demo.common.database.DatabaseUtils;

/**
 * Created by Administrator on 2018/3/25.
 */

public class RegisterActivity extends BaseActivity {

  /*@Override
    protected void onCreat(Bundle savedInstanceState){
      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_register);
      Button code_btn=findViewById(R.id.code_btn);
  }
  @Override
    public void onClick(View V)
*/
    @Bind(R.id.top_text)
    TextView mTopText;
    private Button register_btn;
    private EditText login_phone;
    private EditText login_pass;

    private ImageView top_back;
    @Override
    protected int getResourceId() {
        return R.layout.activity_register;
    }

    public void initView()
    {
        super.initView();
        mTopText.setText("注册账号");
        top_back  = findViewById(R.id.top_back);
        login_phone = findViewById(R.id.login_phone);
        login_pass = findViewById(R.id.login_pass);
        register_btn = findViewById(R.id.register_btn_01);
        top_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegisterActivity.this.finish();
            }
        });
        register_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(login_phone.getText().toString())){
                    Toast.makeText(RegisterActivity.this,"手机号码不能为空",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(login_pass.getText().toString())){
                    Toast.makeText(RegisterActivity.this,"密码不能为空",Toast.LENGTH_SHORT).show();
                    return;
                }
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {

                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        //注册的数据保存在数据库中
                        long index = DatabaseUtils.saveUser(login_phone.getText().toString(),login_pass.getText().toString());
                        if(index == -1){
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(RegisterActivity.this,"注册失败!",Toast.LENGTH_SHORT).show();
                                }
                            });
                        }else if(index == -2){
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(RegisterActivity.this,"用户名已经存在!",Toast.LENGTH_SHORT).show();
                                }
                            });
                        }else {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(RegisterActivity.this,"注册成功,请登录!",Toast.LENGTH_SHORT).show();
                                    RegisterActivity.this.finish();
                                }
                            });
                        }

                    }
                });
                thread.start();

            }
        });
    }
}
