package cn.demo.common.database;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import cn.demo.FruitContext;
import cn.demo.common.constant.ServerConstant;
import cn.demo.http.model.User;


public class DatabaseUtils {

    //登录时，获取用户信息，进行校验
    public static User getUserInfo(String user_name, String password) {
        User detail = null;
        Cursor cursor = null;
        SQLiteDatabase db = FruitContext.getInstance().dbHelper.getReadableDatabase();
        try{
            String sql = null;
            sql = "select * from "+ ServerConstant.TBL_USER+" where  user_name = '"+user_name+"' and password = '"+ password+"'";
            cursor = db.rawQuery(sql,null);
            if(cursor.getCount() > 0 ){
                while(cursor.moveToNext()){
                    detail = new User();
                    detail.set_id(cursor.getInt(cursor.getColumnIndex("_id")));
                    detail.setUser_name(cursor.getString(cursor.getColumnIndex("user_name")));
                    detail.setPassword(cursor.getString(cursor.getColumnIndex("password")));
                }
            }
        }catch(Exception e){
            e.printStackTrace();
            return detail;
        }finally{
            if(cursor != null){
                cursor.close();
                cursor = null;
            }
        }
        return detail;
    }

    //返回值   -2 ：代表用户名已经存在  -1：代表未知错误  其他值代表保存成功
    public static long saveUser(String user_name, String password){
        long result = -1;
        Cursor cursor = null;
        //数据库缓存
        SQLiteDatabase db = FruitContext.getInstance().dbHelper.getReadableDatabase();
        try{
            String sql = null;
            sql = "select * from "+ ServerConstant.TBL_USER+" where  user_name = '"+user_name+"'";
            cursor = db.rawQuery(sql,null);
            if(cursor.getCount() > 0 ){
                return -2;
            }
            ContentValues cv = new ContentValues();
            cv.put("user_name",user_name);
            cv.put("password",password);
            result = db.insert(ServerConstant.TBL_USER, null, cv);
        }catch(Exception e){
            e.printStackTrace();
        }
        return result;
    }

}
