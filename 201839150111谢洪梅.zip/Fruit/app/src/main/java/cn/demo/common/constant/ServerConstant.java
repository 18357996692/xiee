package cn.demo.common.constant;

public class ServerConstant {

    //用户信息表
    public static final String TBL_USER = "tbl_user";

}
