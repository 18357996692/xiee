package cn.demo.ui.fragment;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

import cn.demo.R;
import cn.demo.base.BaseFragment;
import cn.demo.http.adapter.GoodsAdapter2;
import cn.demo.http.model.Goods;

public class  ShopFragment extends BaseFragment{

    public static ArrayList<Goods> shopList = new ArrayList<>();
    GoodsAdapter2 adapter;
    private TextView total_price;
    @Override
    protected int getResourceId() {
        return R.layout.fragment_shop;
    }
    @Override
    public void initView(View rootView){
        super.initView(rootView);
        RecyclerView recyclerView = rootView.findViewById(R.id.recycler_view);
        total_price = rootView.findViewById(R.id.total_price);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(),LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new GoodsAdapter2(getActivity(),shopList,this);
        recyclerView.setAdapter(adapter);
        refreshPrice();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        adapter.notifyDataSetChanged();
        refreshPrice();
    }

    public void refreshPrice(){
        int total = shopList.size()*30;
        total_price.setText("¥ "+total);
    }


}