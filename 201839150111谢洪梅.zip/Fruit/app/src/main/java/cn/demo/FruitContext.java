package cn.demo;

import android.content.Context;

import cn.demo.common.database.DBHelper;
import cn.demo.http.model.User;
import cn.demo.ui.activity.DemoApplication;

public class FruitContext {
    private static FruitContext mDemoContext;
    public Context mContext;
    private User currentUser;
    public DBHelper dbHelper ;
    private DemoApplication application;

    public static FruitContext getInstance() {
        return mDemoContext;
    }

    public static void init(Context context) {
        if (mDemoContext == null) {
            mDemoContext = new FruitContext(context);
        }
    }

    public Context getmContext() {
        return mContext;
    }

    private FruitContext(Context context) {
        mContext = context;
        application = (DemoApplication) context.getApplicationContext();
        dbHelper = new DBHelper(mContext, "shop.db3", null, 1);
    }

    public DBHelper getDbHelper() {
        return dbHelper;
    }

    public void setDbHelper(DBHelper dbHelper) {
        this.dbHelper = dbHelper;
    }


    public DemoApplication getApplication() {
        return application;
    }

    public void setApplication(DemoApplication application) {
        this.application = application;
    }

    //获取登录用户信息
    public User getCurrentUser() {
        return currentUser;
    }


    //缓存登录用户信息
    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }
}
