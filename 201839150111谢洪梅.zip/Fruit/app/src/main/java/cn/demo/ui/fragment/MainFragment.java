package cn.demo.ui.fragment;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;
import com.youth.banner.Transformer;
import com.youth.banner.loader.ImageLoader;

import java.util.ArrayList;
import java.util.List;


import butterknife.OnClick;
import cn.demo.R;
import cn.demo.base.BaseFragment;
import cn.demo.http.model.Goods;
import cn.demo.ui.activity.GoodDetailActivity;
import cn.demo.ui.activity.GoodListActivity;

/**
 * Created by Administrator on 2018/3/24.
 */

public class  MainFragment extends BaseFragment {

    private List<String> imageArray;
    private List<String> imageTitle;
    private Banner mBanner;
    private Intent intent;

    private LinearLayout type_1;
    private LinearLayout type_2;
    private LinearLayout type_3;
    private LinearLayout type_4;

    private RelativeLayout sellFruit1;
    private RelativeLayout sellFruit2;
    @Override
    protected int getResourceId() {
        return R.layout.fragment_main;
    }

    @Override
    public void initView(View rootView){
        super.initView(rootView);
        //设置图片加载集合
        imageArray=new ArrayList<>();
        imageArray.add("http://img.zcool.cn/community/015cb75718419a32f8758c9b132f6f.jpg");
        imageArray.add("https://dss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=3841207884,3037132678&fm=26&gp=0.jpg");
        imageArray.add("https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1521870435614&di=1723825f7a1cdf0419cef4a547b310a1&imgtype=0&src=http%3A%2F%2Fimg.yzcdn.cn%2Fupload_files%2F2015%2F08%2F15%2FFkh5gcUpCQkxYjCCWYRBNQvzLUJd.jpg%2521730x0.jpg");
        imageArray.add("https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1521870483720&di=724e02167ee3c729c25ce003586b234d&imgtype=0&src=http%3A%2F%2Fimg13.360buyimg.com%2Fimgzone%2Fjfs%2Ft145%2F204%2F875023852%2F186430%2F6301044c%2F539bd57fNf56897e3.jpg");


        //设置图片标题集合
        imageTitle=new ArrayList<>();
        imageTitle.add("石榴");
        imageTitle.add("苹果");
        imageTitle.add("葡萄");
        imageTitle.add("芒果");


        mBanner = (Banner)rootView.findViewById(R.id.banner);
        //设置banner样式
        mBanner.setBannerStyle(BannerConfig.CIRCLE_INDICATOR_TITLE_INSIDE);
        //设置图片加载器
        mBanner.setImageLoader(new GlideImageLoader());
        //设置图片集合
        mBanner.setImages(imageArray);
        //设置banner动画效果
        mBanner.setBannerAnimation(Transformer.RotateDown);
        //设置标题集合（当banner样式有显示title时）
        mBanner.setBannerTitles(imageTitle);
        //设置轮播时间
        mBanner.setDelayTime(1500);
        //设置指示器位置（当banner模式中有指示器时）
        mBanner.setIndicatorGravity(BannerConfig.CENTER);
        //banner设置方法全部调用完毕时最后调用
        mBanner.start();

        sellFruit1 = rootView.findViewById(R.id.sellFruit1);
        sellFruit2 = rootView.findViewById(R.id.sellFruit2);
        type_1 = rootView.findViewById(R.id.type_1);
        type_2 = rootView.findViewById(R.id.type_2);
        type_3 = rootView.findViewById(R.id.type_3);
        type_4 = rootView.findViewById(R.id.type_4);
        type_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(),GoodListActivity.class);
                intent.putExtra("type",1);
                startActivity(intent);
            }
        });
        type_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(),GoodListActivity.class);
                intent.putExtra("type",2);
                startActivity(intent);
            }
        });
        type_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(),GoodListActivity.class);
                intent.putExtra("type",3);
                startActivity(intent);
            }
        });
        type_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(),GoodListActivity.class);
                intent.putExtra("type",4);
                startActivity(intent);
            }
        });


        sellFruit1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Goods goods = new Goods("台湾茂谷柑",true,R.drawable.sellorange);
                goods.setGoodsMsg("浓甜无渣 瓣瓣多汁");
                goods.setDes("茂谷柑英名“Murcott\"、“Honey tangerine”,或“Honey murcott\",为美国佛罗里达州迈阿密农业试验所的W.T.Swingle等人于1913年育成的宽皮桔与甜橙的杂交种，即桔橙类 (tangors)里面的杂柑。70年代台湾大学园艺系林扑教授将该品种引入台湾北部地区试种。由于茂谷柑糖度高，风味佳而浓郁、皮薄多汁，且较蕉柑晚熟，因而在台湾市场的售价较蕉柑高出许多，栽培面积逐年增加。近年来闽南地区和广西南宁市武鸣区也已有引种试种。\n" +
                        "2-3月成熟，与青见柑橘、沃柑等都属于春桔。");
                Intent intent = new Intent(getActivity(), GoodDetailActivity.class);
                intent.putExtra("data",goods);
                startActivity(intent);
            }
        });
        sellFruit2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Goods goods = new Goods("经典红富士",true,R.drawable.sellapple);
                goods.setGoodsMsg("优质苹果 香甜爽口");
                goods.setDes("红富士苹果为大型果，平均单果重180～300克，最大单果重可达400克以上。果实多为扁圆形，果形指数0．8左右，少数果近圆形。授粉不良或花序坐果多时，易产生畸肩、偏斜形果实。果梗较细，少数果梗基部有肉质突起。梗洼较广，中深较缓，偶尔有裂口。尊洼中深，较广而缓。果皮光滑有光泽，中厚而韧，光滑，蜡质中多。成熟果实果面底色淡黄，着暗红或鲜红色霞或条霞。果点圆形，较明显，中大，较密，阳面果点黄白色，阴面果点黄色。果肉黄白色，肉质致密，细脆、果汁多。酸甜适口，芳香味浓，品质极上。果实可溶性固形物含量为15.3%～16.0%，酸含量为0.2%～0.4%，果实硬度8.60～10.89公斤/平方厘米。极耐贮运，可贮到翌年四、五月份。贮后肉质不发绵，风味变化小，失重少，病害轻。");
                Intent intent = new Intent(getActivity(), GoodDetailActivity.class);
                intent.putExtra("data",goods);
                startActivity(intent);
            }
        });
    }

    @OnClick({R.id.btn_to_research})
    public void onViewClicked(View view){
        switch (view.getId()){
            case R.id.btn_to_research:
                intent = new Intent(getActivity(),GoodListActivity.class);
                startActivity(intent);
                break;
            default:
                break;

        }
    }



    private class GlideImageLoader extends ImageLoader {
        public void displayImage(Context context, Object path, ImageView imageView) {
//         Glide 加载图片简单用法
            Glide.with(context).load((String) path).into(imageView);

        }
    }

}