package cn.demo.http.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import cn.demo.R;
import cn.demo.cache.ImageCacheManger;
import cn.demo.http.model.Goods;
import cn.demo.ui.fragment.ShopFragment;

import static cn.demo.ui.activity.GoodListActivity.b;

public class GoodsAdapter2 extends RecyclerView.Adapter<GoodsAdapter2.ViewHolder>{

    private List<Goods> mGoodsList;
    private LayoutInflater layoutInflater;

    private ShopFragment fragment;
    private Context mCotext;
    public GoodsAdapter2(Context context, List<Goods> goodsList,ShopFragment fragment) {
        mGoodsList = goodsList;
        this.fragment = fragment;
        mCotext = context;
        layoutInflater = LayoutInflater.from(context);
    }

    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = layoutInflater.inflate(R.layout.item_goods2, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }


    //设置图片
    @Override
    public void onBindViewHolder(GoodsAdapter2.ViewHolder holder, final int position) {
        final Goods goods = mGoodsList.get(position);
        holder.goodsName.setText(goods.getGoodsName()); //获得商品的名称
        holder.tv_item_normal_detail.setText(goods.getGoodsMsg()); //获得商品的名称
        holder.add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mGoodsList.remove(position);
                notifyDataSetChanged();
                Toast.makeText(mCotext,"删除成功",Toast.LENGTH_SHORT).show();
                fragment.refreshPrice();
            }
        });
        if(goods.isLocalImage()){
            holder.goodsImage.setImageResource(goods.getLocalImageRes());
        }else {
            ImageCacheManger.loadImage(goods.getgoodsImage(), holder.goodsImage,
                    b, b);
        }
    }

    public int getItemCount() {
        return mGoodsList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView goodsImage;
        TextView goodsName;
        TextView tv_item_normal_detail;
        ImageView add;
        public ViewHolder(View view) {
            super(view);
            goodsImage = view.findViewById(R.id.goods_image);
            goodsName = view.findViewById(R.id.goods_name);
            tv_item_normal_detail = view.findViewById(R.id.tv_item_normal_detail);
            add = view.findViewById(R.id.add);
        }
    }

}