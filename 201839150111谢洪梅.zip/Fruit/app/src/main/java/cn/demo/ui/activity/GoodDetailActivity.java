package cn.demo.ui.activity;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import cn.demo.R;
import cn.demo.base.BaseActivity;
import cn.demo.http.model.Goods;
import cn.demo.ui.fragment.ShopFragment;

public class GoodDetailActivity extends BaseActivity {
    @Override
    protected int getResourceId() {
        return R.layout.activity_good_detail;
    }

    ImageView goodsImage;
    TextView goodsName;
    TextView goodsMsg;
    TextView des;
    ImageView add;
    private Goods goods ;
    @Override
    public void initView() {
        super.initView();
        goodsImage = findViewById(R.id.goodsImage);
        goodsName = findViewById(R.id.goodsName);
        goodsMsg = findViewById(R.id.goodsMsg);
        des = findViewById(R.id.des);
        add = findViewById(R.id.add);
        goods = (Goods) getIntent().getSerializableExtra("data");
        if(goods.isLocalImage()){
          goodsImage.setImageResource(goods.getLocalImageRes());
        }
        goodsName.setText(goods.getGoodsName());
        goodsMsg.setText(goods.getGoodsMsg());
        des.setText(goods.getDes());
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShopFragment.shopList.add(goods);
                Toast.makeText(GoodDetailActivity.this,"添加成功,请在购物车查看",Toast.LENGTH_SHORT).show();
            }
        });
    }
}
